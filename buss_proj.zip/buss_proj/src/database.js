const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./tickets.db');

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      card_number TEXT,
      expiry_date TEXT,
      cvv TEXT,
      purchase_date TEXT
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS my_tickets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ticket_name TEXT,
      purchase_date TEXT
    )
  `);
});

module.exports = db;