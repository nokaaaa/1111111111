document.addEventListener('DOMContentLoaded', function () {
    const buyBtn = document.getElementById('buy-tickets');

    if (buyBtn) {
        buyBtn.addEventListener('click', function () {
            const selectedSeats = document.querySelectorAll('.seat.selected');
            const seatNumbers = Array.from(selectedSeats).map(seat => seat.dataset.seatNumber);

            if (seatNumbers.length === 0) {
                alert('Пожалуйста, выберите хотя бы одно место.');
                return;
            }

            fetch('/buy_seats/', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRFToken': getCSRFToken()
                },
                body: JSON.stringify({
                    seats: seatNumbers,
                    route_id: getSelectedRouteId()  // заменишь на своё, если нужно
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.redirect_url) {
                    window.location.href = "/payment/";
                } else {
                    alert('Ошибка при покупке билета.');
                }
            })
            .catch(err => {
                console.error('Ошибка:', err);
                alert('Ошибка на сервере.');
            });
        });
    }

    function getCSRFToken() {
        const cookie = document.cookie.split('; ').find(row => row.startsWith('csrftoken='));
        return cookie ? cookie.split('=')[1] : '';
    }

    function getSelectedRouteId() {
        // если у тебя route_id фиксирован, можно вернуть напрямую:
        return 1;
        // либо вытащи из скрытого input-а или data-атрибута
    }
});
